//
//  Spine.h
//  Spine
//
//  Created by Ward van Teijlingen on 30-08-14.
//  Copyright (c) 2014 Ward van Teijlingen. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Spine.
FOUNDATION_EXPORT double SpineVersionNumber;

//! Project version string for Spine.
FOUNDATION_EXPORT const unsigned char SpineVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Spine/PublicHeader.h>


